每3小时自动抓取
```
https://www.wetest.vip/page/cloudflare/address_v4.html
```
和
```
 https://ip.164746.xyz
```
```
 https://cf.090227.xyz
```
```
https://stock.hostmonit.com/CloudFlareYes
```
的优选ip，形成ip.txt 


cfip脚本可以在手机termux上使用
```
curl -sSL https://gh-proxy.com/https://raw.githubusercontent.com/wokaotianshi123/cf-clean-ips/main/cfip.sh -o cfip.sh && chmod +x cfip.sh && bash cfip.sh

```
enpip脚本也可以在手机termux上使用
```
curl -sSL https://gh-proxy.com/https://raw.githubusercontent.com/wokaotianshi123/cf-clean-ips/main/endip.sh -o endip.sh && chmod +x endip.sh && bash endip.sh

```
